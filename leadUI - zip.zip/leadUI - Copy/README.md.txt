# Lead Management MERN App

Simple Lead Management application built with the MERN stack.

**Key Technologies:**

-   MongoDB
-   Express.js
-   React.js
-   Node.js

## Features

-   Add, view, edit, and delete leads (name, email, phone, message)
-   Responsive UI

## Prerequisites

-   Node.js & npm ([Download](https://nodejs.org/))
-   MongoDB ([Install](https://docs.mongodb.com/manual/installation/)) or MongoDB Atlas

## Backend Setup

1.  **Navigate to backend:** `cd server`
2.  **Install:** `npm install`
3.  **Configure MongoDB:**
    -   Local: MongoDB should be running at `mongodb://localhost:27017/lead_management`
    -   Remote: Set `MONGODB_URI` env variable.  Example:
        -   `.env` file: `MONGODB_URI=your_mongodb_connection_string`
        -   Linux/macOS: `export MONGODB_URI="your_mongodb_connection_string"`
        -   Windows (PowerShell): `$env:MONGODB_URI="your_mongodb_connection_string"`
4.  **Start server:** `npm run dev`
5.  **Verify API:** (Add your actual endpoint here. Example: `http://localhost:6001/api/leads`)

## Frontend Setup

1.  **Navigate to frontend:** `cd client`
2.  **Install:** `npm install`
3.  **Start:** `npm start` (opens UI in browser at `http://localhost:3000`)
4.  **Configuration:** If backend API is not at `http://localhost:6001/api`, update `apiBaseUrl` in `frontend/src/App.js`

## Usage

-   Add leads via the form (Name, Email, and Phone are required).
-   Leads are displayed in a list with edit/delete options.
-   Edit pre-fills the form.
-   Delete prompts for confirmation.

## Troubleshooting

-   Ensure both backend and frontend servers are running.
-   Verify MongoDB is running and accessible.
-   Check browser console for CORS errors.
-   Use browser dev tools to debug API errors.

## Project Structure

``
    └── client
        ├── public
        ├── src
        │   ├── App.js
        │   ├── component
        │   |   └── LeadUI.js
        │   ├── style
        │   │   └── LeadUI.css
        │   └── ...
        ├── package.json
        └── ...
    |── server
        ├── models
        │   └── Lead.js
        ├── server.js
        ├── package.json
        └── ...
    ```
    
## License

Open-source and free to use.

## Acknowledgments

Thanks to the open-source community.
