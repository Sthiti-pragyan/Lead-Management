const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const Lead = require('./models/Lead');

const app = express();
const PORT = process.env.PORT || 6001;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/lead_management';

app.use(cors());
app.use(bodyParser.json());

mongoose.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

// REST API routes
app.get('/api/leads', async (req, res) => {
  try {
    const leads = await Lead.find().sort({ createdAt: -1 });
    res.json(leads);
  } catch (err) { res.status(500).json({ error: 'Server error' }); }
});

app.post('/api/leads', async (req, res) => {
  try {
    const { name, email, phone, message } = req.body;
    if (!name || !email || !phone) return res.status(400).json({ error: 'Name, email and phone are required' });
    const lead = new Lead({ name, email, phone, message });
    await lead.save();
    res.status(201).json(lead);
  } catch (err) { res.status(500).json({ error: 'Server error' }); }
});

app.put('/api/leads/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, phone, message } = req.body;
    const lead = await Lead.findById(id);
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    lead.name = name || lead.name;
    lead.email = email || lead.email;
    lead.phone = phone || lead.phone;
    lead.message = message || lead.message;
    await lead.save();
    res.json(lead);
  } catch (err) { res.status(500).json({ error: 'Server error' }); }
});

app.delete('/api/leads/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const lead = await Lead.findById(id);
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    await lead.deleteOne();
    res.json({ message: 'Lead deleted' });
  } catch (err) { res.status(500).json({ error: 'Server error' }); }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});