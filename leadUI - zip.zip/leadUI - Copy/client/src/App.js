import LeadUI from './component/LeadUI'

function App() {
  return (
    <div className="App">
      <LeadUI/>
    </div>
  );
}

export default App;
