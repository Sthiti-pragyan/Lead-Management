import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './../style/LeadUI.css';

const apiBaseUrl = 'http://localhost:6001/api';

function App() {
  const [leads, setLeads] = useState([]);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [editingLeadId, setEditingLeadId] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchLeads();
  }, []);

  const fetchLeads = async () => {
    try {
      const { data } = await axios.get(`${apiBaseUrl}/leads`);
      setLeads(data);
    } catch {
      setError('Failed to load leads');
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!formData.name || !formData.email || !formData.phone) {
      setError('Name, Email and Phone are required');
      return;
    }
    try {
      editingLeadId
        ? await axios.put(`${apiBaseUrl}/leads/${editingLeadId}`, formData)
        : await axios.post(`${apiBaseUrl}/leads`, formData);
      setFormData({ name: '', email: '', phone: '', message: '' });
      fetchLeads();
      setEditingLeadId(null);
    } catch {
      setError('Failed to save lead');
    }
  };

  const handleEdit = (lead) => {
    setEditingLeadId(lead._id);
    setFormData({ name: lead.name, email: lead.email, phone: lead.phone, message: lead.message || '' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this lead?')) {
      try {
        await axios.delete(`${apiBaseUrl}/leads/${id}`);
        if (editingLeadId === id) {
          setEditingLeadId(null);
          setFormData({ name: '', email: '', phone: '', message: '' });
        }
        fetchLeads();
      } catch {
        setError('Failed to delete lead');
      }
    }
  };

  return (
    <div className="app-container">
      <h1 className="app-header">Lead Management</h1>
      <form onSubmit={handleSubmit} className="form-container">
        <h2 className="form-header">{editingLeadId ? 'Edit Lead' : 'Add New Lead'}</h2>
        {error && <p className="error-message">{error}</p>}
        {['name', 'email', 'phone'].map((field) => (
          <label key={field} className="form-label">
            {field.charAt(0).toUpperCase() + field.slice(1)}:
            <input
              name={field}
              value={formData[field]}
              onChange={handleChange}
              required
              className="form-input"
              type={field === 'email' ? 'email' : 'text'}
            />
          </label>
        ))}
        <label className="form-label">
          Message:
          <textarea name="message" value={formData.message} onChange={handleChange} className="form-input" rows={4} />
        </label>
        <button type="submit" className="submit-button">{editingLeadId ? 'Update Lead' : 'Add Lead'}</button>
        {editingLeadId && <button type="button" onClick={() => setEditingLeadId(null)} className="cancel-button">Cancel</button>}
      </form>

      <h2 className="leads-header">Leads List</h2>
      {leads.length === 0 ? (
        <p className="no-leads-message">No leads found.</p>
      ) : (
        <table className="leads-table">
          <thead>
            <tr>
              {['Name', 'Email', 'Phone', 'Message', 'Actions'].map((header) => (
                <th key={header} className="leads-table-header">{header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {leads.map((lead) => (
              <tr key={lead._id} className="leads-table-row">
                <td className="leads-table-data">{lead.name}</td>
                <td className="leads-table-data">{lead.email}</td>
                <td className="leads-table-data">{lead.phone}</td>
                <td className="leads-table-data">{lead.message || '-'}</td>
                <td className="leads-table-data">
                  <button onClick={() => handleEdit(lead)} className="edit-button">Edit</button>
                  <button onClick={() => handleDelete(lead._id)} className="delete-button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;
